export const DISCONNECT_TIME = 1800; // 30 minutes

export const DOCS_URL =
  'https://bytedance.larkoffice.com/docx/FQJ9dvBE7oLzu3xtacJc6Cyjnof';
