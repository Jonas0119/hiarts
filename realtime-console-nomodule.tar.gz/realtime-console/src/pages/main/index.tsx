import React, { useState, useEffect, useRef, useCallback } from 'react';

import {
  Layout,
  List,
  Card,
  Typography,
  message,
  Row,
  Col,
  Checkbox,
} from 'antd';
import {
  RealtimeClient,
  RealtimeAPIError,
  EventNames,
} from '@coze/realtime-api';
import { type APIError } from '@coze/api';

import { isShowVideo } from '../../utils/utils';
import { LocalManager, LocalStorageKey } from '../../utils/local-manager';
import logo from '../../logo.svg';
import Player from './player';
import Header from './header';

const { Content, Footer } = Layout;
const { Text } = Typography;

// 硬编码配置信息
const CONFIG = {
  //accessToken: 'czu_ljPGRaIpxwKtoNwa6NeMyvblq5zWdbsEnPhfdxwF6nDmR0hz1b5VeqQneWxsaFov3',
  accessToken: 'pat_Pcvuj7NOFT4EfHSJMjqZYDOmbB6TxFSSsr1BHqrUCI7inqWbIxz7vYrRnJEcjpex',
  botId: '7447765883952398386',
  voiceId: '7426720361732915209',
  baseUrl: 'https://api.coze.cn'
};

interface EventData {
  time: string;
  type?: string;
  event: string;
  data?: any;
}

const RealtimeConsole: React.FC = () => {
  const clientRef = useRef<RealtimeClient | null>(null);
  const [events, setEvents] = useState<EventData[]>([]);
  const [serverEvents, setServerEvents] = useState<EventData[]>([]);
  const [autoScrollEvents, setAutoScrollEvents] = useState(true);
  const [autoScrollServerEvents, setAutoScrollServerEvents] = useState(true);
  const eventsEndRef = useRef<HTMLDivElement>(null);
  const serverEventsEndRef = useRef<HTMLDivElement>(null);
  const [isMicrophoneOn, setIsMicrophoneOn] = useState(true);
  const localManager = new LocalManager();

  const handleInitClient = () => {
    if (clientRef.current) {
      return;
    }

    const client = new RealtimeClient({
      accessToken: CONFIG.accessToken,
      botId: CONFIG.botId,
      voiceId: CONFIG.voiceId,
      debug: true,
      baseURL: CONFIG.baseUrl,
      allowPersonalAccessTokenInBrowser: true,
      audioMutedDefault: !isMicrophoneOn,
      suppressStationaryNoise: true,
      suppressNonStationaryNoise: true,
      connectorId: '1024',
      videoConfig: isShowVideo()
        ? {
            renderDom: 'local-player',
            videoOnDefault:
              localManager.get(LocalStorageKey.VIDEO_STATE) === 'true',
          }
        : undefined,
    });

    // Subscribe to all client and server events
    client.on(EventNames.ALL, handleAllMessage);

    clientRef.current = client;
  };

  const handleConnect = async () => {
    // 检查浏览器兼容性
    if (!window.RTCPeerConnection) {
      message.error('Your browser does not support WebRTC. Please use a modern desktop browser.');
      return;
    }

    // 检查麦克风权限
    try {
      // 先检查是否支持 mediaDevices API
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        message.error('Your browser does not support audio input. Please use a modern browser.');
        return;
      }

      // 在移动设备上，先显示提示信息
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      if (isMobile) {
        message.info('Please allow microphone access when prompted');
      }

      // 尝试获取麦克风权限
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      // 获取成功后立即释放流
      stream.getTracks().forEach(track => track.stop());

    } catch (err: unknown) {
      console.error('Microphone access error:', err);
      
      // 根据错误类型显示不同的提示信息
      if (err instanceof Error) {
        switch (err.name) {
          case 'NotAllowedError':
          case 'PermissionDeniedError':
            message.error('Microphone access was denied. Please allow microphone access in your browser settings.');
            break;
          case 'NotFoundError':
            message.error('No microphone found. Please ensure your device has a working microphone.');
            break;
          case 'NotReadableError':
          case 'TrackStartError':
            message.error('Could not start microphone. Please ensure no other app is using it.');
            break;
          default:
            message.error('Failed to access microphone. Please check your device settings.');
        }
      } else {
        message.error('Failed to access microphone. Please check your device settings.');
      }
      return;
    }

    handleInitClient();

    if (!clientRef.current) {
      return;
    }

    try {
      setEvents([]);
      setServerEvents([]);
      await clientRef.current.connect();
      message.success('Connected. Please start the conversation.');
    } catch (e: unknown) {
      if (e instanceof RealtimeAPIError) {
        message.error(`Failed to connect: ${e.message}`);
      } else if (e instanceof Error) {
        message.error(`An error occurred: ${e.message}`);
      } else {
        message.error('An unknown error occurred');
      }
      console.log('Connect error', e);
    }
  };

  const handleAllMessage = useCallback((eventName: string, data: any) => {
    console.log('event', eventName, data);

    if (eventName === EventNames.PLAYER_EVENT) {
      return;
    }

    const now = new Date();
    const time = `${now.toTimeString().split(' ')[0]}.${String(
      now.getMilliseconds(),
    ).padStart(3, '0')}`;
    const type = eventName.split('.')[0];
    const event = eventName.substring(eventName.indexOf('.') + 1);

    setEvents(prevEvents => [...prevEvents, { time, type, event }]);

    if (
      type === 'server' &&
      (data?.data?.role === 'user' ||
        data?.data?.role === 'assistant' ||
        data?.event_type === 'conversation.created' ||
        data?.event_type === 'error')
    ) {
      setServerEvents(prevEvents => {
        const mergedEvent = mergeEvent(prevEvents, { time, event, data });
        if (mergedEvent) {
          return [...prevEvents.slice(0, -1), mergedEvent];
        }
        if (
          data?.event_type === 'error' ||
          data?.event_type === 'conversation.created'
        ) {
          data.data.content = JSON.stringify(data.data);
          data.data.role = 'assistant';
        }
        return [...prevEvents, { time, event, data }];
      });
    }
  }, []);

  const mergeEvent = (prevEvents: any[], event: any) => {
    if (prevEvents.length === 0) {
      return null;
    }
    const lastEvent = prevEvents[prevEvents.length - 1];
    if (
      lastEvent.event === 'conversation.message.delta' &&
      event.event === 'conversation.message.delta'
    ) {
      return {
        time: lastEvent.time,
        event: lastEvent.event,
        data: {
          ...lastEvent.data,
          data: {
            ...lastEvent.data.data,
            content: lastEvent.data.data.content + event.data.data.content,
          },
        },
      };
    }
    return null;
  };

  const handleDisconnect = async () => {
    if (!clientRef.current || !clientRef.current.isConnected) {
      return;
    }

    try {
      await clientRef.current.disconnect();
      clientRef.current.off(EventNames.ALL, handleAllMessage);
      clientRef.current = null;
      message.success('Disconnected');
    } catch (e) {
      if (e instanceof RealtimeAPIError) {
        message.error(`Failed to disconnect: ${e.message}`);
      } else {
        message.error('Failed to disconnect');
      }
      console.error(e);
      return;
    }
  };

  const scrollToBottom = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // set favicon
    const link = document.querySelector("link[rel~='icon']");
    if (link) {
      link.setAttribute('href', logo);
    } else {
      const favicon = document.createElement('link');
      favicon.rel = 'icon';
      favicon.href = logo;
      document.head.appendChild(favicon);
    }
  }, []);

  useEffect(() => {
    if (autoScrollEvents) {
      scrollToBottom(eventsEndRef);
    }
  }, [events, autoScrollEvents]);

  useEffect(() => {
    if (autoScrollServerEvents) {
      scrollToBottom(serverEventsEndRef);
    }
  }, [serverEvents, autoScrollServerEvents]);

  useEffect(() => {
    // 检查浏览器兼容性
    if (!window.RTCPeerConnection) {
      message.warning('For the best experience, please use a modern desktop browser.');
    }
    
    // 检查是否是移动设备
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (isMobile) {
      message.warning('This application works best on desktop browsers. Please ensure microphone permissions are granted in your browser settings.');
    }

    // 检查麦克风API支持
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      message.warning('Your browser might not fully support audio features.');
    }
  }, []);

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Footer style={{ textAlign: 'center' }}>
        <Header
          onConnect={handleConnect}
          onDisconnect={handleDisconnect}
          isConnected={clientRef.current?.isConnected}
          clientRef={clientRef}
          onToggleMicrophone={setIsMicrophoneOn}
          isMicrophoneOn={isMicrophoneOn}
        />
      </Footer>
      {isShowVideo() && <Player clientRef={clientRef} />}
      <Content style={{ padding: '20px' }}>
        <Row gutter={[16, 16]}>
          <Col xs={24} sm={24} md={12} lg={12} xl={12}>
            <Card
              title="Events"
              style={{ marginBottom: '20px' }}
              extra={
                <Checkbox
                  checked={autoScrollEvents}
                  onChange={e => setAutoScrollEvents(e.target.checked)}
                >
                  Auto Scroll
                </Checkbox>
              }
            >
              <List
                dataSource={[...events, { event: 'end', time: '', type: '' }]}
                style={{ maxHeight: '420px', overflow: 'auto' }}
                renderItem={item =>
                  item.event === 'end' ? (
                    <div ref={eventsEndRef} />
                  ) : (
                    <List.Item>
                      <Text>{item.time}</Text>&nbsp;&nbsp;&nbsp;
                      <Text>[{item.type}]</Text>&nbsp;&nbsp;&nbsp;
                      <Text>{item.event}</Text>
                    </List.Item>
                  )
                }
              />
            </Card>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12} xl={12}>
            <Card
              title="User & Assistant"
              extra={
                <Checkbox
                  checked={autoScrollServerEvents}
                  onChange={e => setAutoScrollServerEvents(e.target.checked)}
                >
                  Auto Scroll
                </Checkbox>
              }
            >
              <List
                dataSource={[
                  ...serverEvents,
                  { event: 'end', time: '', type: '' },
                ]}
                style={{ maxHeight: '420px', overflow: 'auto' }}
                renderItem={item =>
                  item.event === 'end' ? (
                    <div ref={serverEventsEndRef} />
                  ) : (
                    <List.Item>
                      <Typography.Paragraph
                        ellipsis={{
                          rows: 1,
                          expandable: true,
                          symbol: 'Show more',
                        }}
                        style={{ margin: 0, width: '100%' }}
                      >
                        {item.time}&nbsp;&nbsp;
                        {item.event}&nbsp;[{item.data?.data?.role}]&nbsp;
                        {item.data?.data?.content}
                      </Typography.Paragraph>
                    </List.Item>
                  )
                }
              />
            </Card>
          </Col>
        </Row>
      </Content>
    </Layout>
  );
};

export default RealtimeConsole;
